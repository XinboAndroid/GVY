import com.navis.inventory.business.api.UnitManager;
import com.navis.inventory.business.api.RectifyParms;
import com.navis.inventory.business.atoms.UnitVisitStateEnum;
import com.navis.apex.business.model.GroovyInjectionBase
import com.navis.argo.business.reference.Equipment
import com.navis.argo.ContextHelper
import com.navis.inventory.business.units.UnitFacilityVisit
import com.navis.framework.business.Roastery;
import com.navis.inventory.business.units.Unit;
import com.navis.inventory.business.api.UnitFinder;
import com.navis.argo.business.api.ArgoUtils;
import com.navis.inventory.business.atoms.UfvTransitStateEnum;

/*
* Class Departs all the UFV Units and sets the Master Visit State Departed 
*/
public class GvyInjNLT extends GroovyInjectionBase 
{
      def ibCarrier = ''
      def obCarrier = ''
      def  inUnit = null

   //Method Set all the Complex Level Active units to Departed 
   public String execute(Map inParameters)
  {
     println("GvyInjNLT.execute(inparameters)")
     try
    {

      //Processing One unit at a time 
      def unitId = (String) inParameters.get("unitId");
      ibCarrier = (String) inParameters.get("ibCarrier");
      obCarrier = (String) inParameters.get("obCarrier");  

      processUnit(unitId) 
      println("After NLT Processing on Units")

     }catch(Exception e){
       e.printStackTrace()
    }

  }//Method execute Ends

   public void processUnit(String unitId)
   {
      try
      {

          Set ufvSet = findVisitStateActiveUnit(unitId)
          for(aUfv in ufvSet)
         {
             def ufvIbCarrier = aUfv.getUfvActualIbCv() != null ? aUfv.getUfvActualIbCv().getCvId() : "";
             def ufvObCarrier = aUfv.getUfvIntendedObCv() != null ? aUfv.getUfvIntendedObCv().getCvId() : "";  

            //If is unit Departed and File IB and OB carrier is same as N4 then Delete unit
           // Added this Code to stop creating Multiple units Entries on the NLT if same NLT is executed twice.
           // If Blank OB in the NLT file then the Delete Check si passed
          println("ibCarrier :"+ibCarrier+"  ufvIbCarrier:"+ufvIbCarrier+"  obCarrier:"+obCarrier+"  ufvObCarrier:"+ufvObCarrier)
          if(ibCarrier.equals(ufvIbCarrier) && obCarrier.equals(ufvObCarrier)){
             Unit myUnit = inUnit
               if(myUnit != null){
                  UnitManager unitManager = (UnitManager) Roastery.getBean(UnitManager.BEAN_ID)
                  unitManager.purgeUnit(myUnit)
                  println("Executed Delete on NLT Unit: "+unitId)
               }
           }
          else  if (!UnitVisitStateEnum.DEPARTED.equals(aUfv.getUfvVisitState())) {
               RectifyParms rparms = new RectifyParms();
               rparms.setUfvTransitState(UfvTransitStateEnum.S70_DEPARTED);
               rparms.setUnitVisitState(UnitVisitStateEnum.DEPARTED)
               aUfv.rectify(rparms);
               println("Executed DEPARTED on NLT Unit: "+unitId) 
            }//If Ends
         }
 
       }catch(Exception e){
            e.printStackTrace()
        }
   }

  // Method returns a Set of Complex Level Master State Active Units 
  public Set findVisitStateActiveUnit(String unitId)
  {
    Set unitUfvSet = null  
    try{
     def unitFinder = getUnitFinder()
     def complex = ContextHelper.getThreadComplex();
     def inEquipment = Equipment.loadEquipment(unitId);
     inUnit = unitFinder.findActiveUnit(complex,inEquipment)
     unitUfvSet = inUnit != null ? inUnit.getUnitUfvSet() : null; 
    }catch(Exception e){
        e.printStackTrace()
    }   
    return unitUfvSet
  }

}//Class Ends