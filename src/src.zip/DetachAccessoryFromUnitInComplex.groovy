import com.navis.argo.ContextHelper
import com.navis.argo.business.reference.Accessory
import com.navis.framework.business.Roastery
import com.navis.framework.persistence.HibernateApi
import com.navis.inventory.business.api.UnitFinder
import com.navis.inventory.business.units.Unit
import com.navis.inventory.business.units.UnitEquipment
import com.navis.inventory.business.units.UnitFacilityVisit
import com.navis.road.business.model.TruckTransaction
import com.navis.road.business.workflow.TransactionAndVisitHolder
import com.navis.inventory.business.atoms.EqUnitRoleEnum
import com.navis.argo.business.model.CarrierVisit

/**
 * Detaches a chassis from a unit facility visit that has departed the facility but remains in the complex.
 * This task is required so that chassis attached to a dray-off unit can be returned back into the gate.
 */
public class DetachAccessoryFromUnitInComplex {


   public static String BEAN_ID = "detachAccessoryFromUnitInComplex"

    public void execute(TransactionAndVisitHolder dao, api) {
       TruckTransaction tran = dao.tran
        Accessory acc = tran.tranChsAccessory
        if (!acc)
            return
        UnitFinder unitFinder = (UnitFinder) Roastery.getBean(UnitFinder.BEAN_ID)
        UnitEquipment unitEq = unitFinder.findActiveUeUsingEqInAnyRole(null, ContextHelper.getThreadComplex(), acc)
        if (!unitEq)
            return

        Unit unit = unitEq.ueUnit
        if (!unit)
            return

        if (EqUnitRoleEnum.PRIMARY.equals(unitEq.getUeEqRole())) {
            unit.makeRetired();
            HibernateApi.getInstance().flush()
            return;
        }
        UnitFacilityVisit ufv = unit.getUfvForFacilityNewest(ContextHelper.getThreadFacility())
        if (!ufv)
            return
        // uncomment the if condition below when chassis inventory is managed properly
        //if (!ufv.isInFacility()) {
            unit.detachAccessoriesOnChassis("groovy")
        //}
        // The flush is required to synchronize memory state of the unit with database state of the unit
        // so that the next findActiveUe will not result in an active chassis unit equipment.
        HibernateApi.getInstance().flush()
    }
}
