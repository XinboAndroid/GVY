/*
 * Copyright (c) 2015 Navis LLC. All Rights Reserved.
 *
 */

import com.navis.argo.ContextHelper
import com.navis.argo.business.api.ArgoUtils
import com.navis.argo.business.model.GeneralReference
import com.navis.argo.util.PrintUtil
import com.navis.external.road.AbstractGateTaskInterceptor
import com.navis.external.road.EGateTaskInterceptor
import com.navis.framework.AllOtherFrameworkPropertyKeys
import com.navis.framework.MailServerConfig
import com.navis.framework.business.atoms.PrinterDriverEnum
import com.navis.framework.persistence.HibernateApi
import com.navis.framework.portal.Ordering
import com.navis.framework.portal.QueryUtils
import com.navis.framework.portal.UserContext
import com.navis.framework.portal.query.DomainQuery
import com.navis.framework.portal.query.PredicateFactory
import com.navis.framework.printing.PrintRequest
import com.navis.framework.printing.PrintServiceManager
import com.navis.framework.util.BizFailure
import com.navis.framework.util.BizViolation
import com.navis.framework.util.io.ResourceUtils
import com.navis.road.RoadEntity
import com.navis.road.RoadField
import com.navis.road.business.atoms.TranStatusEnum
import com.navis.road.business.atoms.TranSubTypeEnum
import com.navis.road.business.model.Document
import com.navis.road.business.model.GateLane
import com.navis.road.business.model.TruckTransaction
import com.navis.road.business.reference.Printer
import com.navis.road.business.util.RoadBizUtil
import com.navis.road.business.workflow.TransactionAndVisitHolder
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.springframework.core.io.Resource
import org.springframework.mail.MailSendException
import org.springframework.mail.javamail.JavaMailSenderImpl
import org.springframework.mail.javamail.MimeMessageHelper

import javax.mail.internet.MimeMessage
import java.nio.charset.Charset

import static com.navis.argo.business.reference.HardwareDevice.findHardwareDeviceById

/**
 * Print document.
 *
 * @author <a href="mailto:balamurugan.bakthavachalam@navis.com"> Balamurugan B</a> Date: 07/17/2015
 *
 * Date: 07/17/2015: 5:41 PM
 * JIRA: CSDV-3024
 * SFDC: 00138337
 * Called from: Gate Configuration
 * ---------------------------------------------------------------------------------------------------------------------------------------------------
 * Revision History
 * ---------------------------------------------------------------------------------------------------------------------------------------------------
 */
public class MatsonAncPrintDocument extends AbstractGateTaskInterceptor implements EGateTaskInterceptor {

    /**
     * Print document based on the configuration docTypeId parameter
     *
     * @param inOutDao
     */
    public void execute(TransactionAndVisitHolder inOutDao) {
        LOGGER.setLevel(Level.INFO);
        LOGGER.info(" MatsonAncPrintDocument execute Stared.");
        def matsonAncValidateGateDocuments = getLibrary("MatsonAncValidateGateDocuments");
        LOGGER.info("MatsonAncCreateDocument about to execute MatsonAncValidateGateDocuments");
        if (!matsonAncValidateGateDocuments.isValidationSuccess(inOutDao)) {
            return;
        }
        if (!RoadBizUtil.getMessageCollector().hasError() && !inOutDao.hasTransaction()) {
            LOGGER.error(" MatsonAncPrintDocument: No truck transaction found or transaction has one or more errors.");
            return;
        }
        TruckTransaction tran = inOutDao.getTran();
        GateLane lane = inOutDao.getTran().getTranTruckVisit().getTvdtlsExitLane();
        GeneralReference ftpGeneralReference = GeneralReference.findUniqueEntryById("MATSON", "FTP", "INFO", lane.getLaneId());
        List<Document> docList = findDocByTransaction(inOutDao.getTran());
        if (docList == null) {
            LOGGER.error(" MatsonAncPrintDocument: No document found for transaction Nbr:" + tran.getTranNbr());
            return;
        }
        for (Document doc : docList) {
            saveDocument(doc, inOutDao, ftpGeneralReference);
        }

        LOGGER.info(" MatsonAncPrintDocument execute Completed.");
    }

    private static List<Document> findDocByTransaction(TruckTransaction inTran) {
        DomainQuery dq = QueryUtils.createDomainQuery(RoadEntity.DOCUMENT);
        dq.addDqPredicate(PredicateFactory.eq(RoadField.DOC_TRANSACTION, inTran.getTranGkey()));
        dq.addDqOrdering(Ordering.asc(RoadField.DOC_CREATED));
        return (List<Document>) HibernateApi.getInstance().findEntitiesByDomainQuery(dq);
    }

    private void saveDocument(
            final Document inDocument, TransactionAndVisitHolder inOutDao, GeneralReference inReference) {
        String docTypeId = inDocument.getDocDocType().getDoctypeId();
        try {
            TruckTransaction tran = inOutDao.getTran();
            GeneralReference generalReferenceDamages = GeneralReference.findUniqueEntryById("MATSON", "DOCUMENTS", "DAMAGES");
            boolean printDamage = tran.getTranChsDmg() != null && tran.getTranChsDmg().getDmgsItems() != null &&
                    !tran.getTranChsDmg().getDmgsItems().isEmpty() && generalReferenceDamages.getRefValue1().equals(docTypeId);
            if (Boolean.TRUE.equals(printDamage) || TranStatusEnum.TROUBLE.equals(inOutDao.getTran().getTranStatus())) {
                printFile(inDocument, inOutDao);
            } else {
                GateLane lane = tran.getTranTruckVisit().getTvdtlsExitLane();
                if (lane == null) {
                    RoadBizUtil.
                            appendExceptionChain(
                                    BizViolation.create(AllOtherFrameworkPropertyKeys.ERROR__NULL_MESSAGE, null, "Couldn't find Gate Entry Lane."));
                    return;
                }
                String laneId = lane.getLaneId();
                String fileName = inOutDao.getTran().getTranNbr() + "_" + docTypeId + "_" + ArgoUtils.timeNowMillis() + ".txt";
                String notes = "";
                boolean changeNotes = false;
                if (TranSubTypeEnum.DB.equals(inOutDao.getTran().getTranSubType()) ||
                        TranSubTypeEnum.DC.equals(inOutDao.getTran().getTranSubType()) ||
                        TranSubTypeEnum.DE.equals(inOutDao.getTran().getTranSubType()) ||
                        TranSubTypeEnum.DI.equals(inOutDao.getTran().getTranSubType()) ||
                        TranSubTypeEnum.DM.equals(inOutDao.getTran().getTranSubType())) {
                    changeNotes = true;
                    notes = inOutDao.getTran().getTranFlexString08();
                }
                for (Object obj : inDocument.getDocMessages()) {
                    LOGGER.info(obj);
                }
                if (changeNotes) {
                }
                Set<String> set = new HashSet<>(1);
                set.add(notes);
                inDocument.set
                }
                byte[] printByte = inDocument.transformData(PrinterDriverEnum.CUSTOM);
                InputStream is = new ByteArrayInputStream(printByte);
                def matsonAncFtpAdaptor = getLibrary("MatsonAncFtpAdaptor");
                try {
                    LOGGER.info("MatsonAncPrintDocument about to execute MatsonAncFtpAdaptor");
                    matsonAncFtpAdaptor.openConnection(inReference);
                    matsonAncFtpAdaptor.sendDocument(fileName, is);
                } finally {
                    matsonAncFtpAdaptor.closeConnection();
                }
            }
        catch (BizViolation bizViolation) {
            RoadBizUtil.appendExceptionChain(bizViolation);
        }
    }

    private void printFile(Document inDocument, TransactionAndVisitHolder inOutDao) {
        GeneralReference reference = null;
        boolean isTrouble = TranStatusEnum.TROUBLE.equals(inOutDao.getTran().getTranStatus());
        if (isTrouble) {
            reference = GeneralReference.findUniqueEntryById("MATSON", "PRINTER_NAME", "TROUBLE");
        } else {
            reference = GeneralReference.findUniqueEntryById("MATSON", "PRINTER_NAME", "DAMAGES");
        }
        Printer printer = findHardwareDeviceById(reference.getRefValue1()) as Printer;
        byte[] data = inDocument.transformData(printer.getPrinterDriver());
        if (printer != null) {
            //email notification for chassis damage.
            if (!isTrouble) {
                GeneralReference emailIdGeneralReference = GeneralReference.findUniqueEntryById("MATSON", "EMAIL", "NOTIFICATION");
                String fromEmailId = emailIdGeneralReference.getRefValue1();
                String toEmailId = emailIdGeneralReference.getRefValue2();
                String subject = "Damage Report for Chassis: " + inOutDao.getTran().getTranChsNbr();
                boolean result = sendEmail(toEmailId, fromEmailId, subject, new String(transformData(inDocument.getDocData()), "UTF-8"));
                if (result) {
                    LOGGER.info("MatsonAncPrintDocument:Email notification has been sent to " + toEmailId);
                } else {
                    LOGGER.error("MatsonAncPrintDocument:Failed to send Email notification to " + toEmailId);
                }
            }
            PrintUtil.print(data, printer.getHwHostAddress(), printer.getPrtrQueueName(), 1);
        } else {
            String msg = "Couldn't find printer for ID:" + reference.getRefValue1() + ". Please configure correct printer IP address in General reference.";
            LOGGER.error(msg);
            RoadBizUtil.appendExceptionChain(BizViolation.create(AllOtherFrameworkPropertyKeys.ERROR__NULL_MESSAGE, null, msg));
            return;
        }
    }

/**
 * Send simple email message
 *
 * @param inTo TO email address
 * @param inFrom FROM email address
 * @param inSubject Text in the subject line
 * @param inBody Text in the body of the email
 * @return TRUE/FALSE     True if email has been sent or not
 */
    public Boolean sendEmail(String inTo, String inFrom, String inSubject, String inBody) {
        GroovyEmailSender sender = new GroovyEmailSender();
        MimeMessage msg = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(msg, "UTF-8");
        helper.setFrom(inFrom);
        helper.setReplyTo(inFrom);
        helper.setTo(inTo);
        helper.setSubject(inSubject);
        helper.setText(inBody, true);
        try {
            sender.send(msg);
        } catch (Exception inException) {
            LOGGER.error("MatsonAncPrintDocument: Exception in email attempt: " + inException);
            return false;
        }
        return true;
    }

    private class GroovyEmailSender extends JavaMailSenderImpl {
        GroovyEmailSender() {
            setMailServerPropertiesFromUserContext();
        }
        /**
         * Sets the Host, Port, and Protocol from the config settings based on the UserContext from the email message.
         *
         * @param inEmailMessage
         */
        private void setMailServerPropertiesFromUserContext() {
            try {
                UserContext userContext = ContextHelper.getThreadUserContext();
                setHost(MailServerConfig.HOST.getSetting(userContext));
                setPort(Integer.parseInt(MailServerConfig.PORT.getSetting(userContext)));
                String protocol = MailServerConfig.PROTOCOL.getSetting(userContext);
                long timeout = MailServerConfig.TIMEOUT.getValue(userContext);
                Properties props = new Properties();
                props.setProperty("mail.pop3.timeout", String.valueOf(timeout));
                setProtocol(protocol);
                if ("smtps".equals(protocol)) {
                    setUsername(MailServerConfig.SMTPS_USER.getSetting(userContext));
                    setPassword(MailServerConfig.SMTPS_PASSWORD.getSetting(userContext));
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtps.auth", "true");
                    props.put("mail.smtp.ssl.enable", "true");
                    props.put("mail.transport.protocol", "smtps");
                }
                setJavaMailProperties(props);
                LOGGER.info("Initialized SMTP Mail Server Configuration.");
            } catch (Throwable throwable) {
                String error = "Initializing the SMTP Mail Server configuration encountered the following error:";
                LOGGER.error(error, throwable);
                throw new MailSendException(error, throwable);
            }
        }
        private Logger LOGGER = Logger.getLogger(GroovyEmailSender.class);
    }

    private static byte[] transformData(String inInputData) {
        PrintRequest printRequest = new PrintRequest();
        ByteArrayInputStream byteStream = null;
        try {
            byte[] xslLayout = htmlLayout.getBytes(Charset.forName("UTF-8"));
            byteStream = new ByteArrayInputStream(xslLayout);
            Resource resource = ResourceUtils.loadSerializableInputStreamResource(byteStream);
            printRequest.setSource(inInputData.getBytes(Charset.forName("UTF-8")));
            printRequest.setPrintDriverFormat(PrinterDriverEnum.CUSTOM);
            printRequest.setPrintDriverResource(resource);
        } catch (IOException ioe) {
            throw BizFailure.wrap(ioe);
        }
        return new PrintServiceManager().convertToDriverFormat(printRequest);
    }

    private static htmlLayout = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" xmlns:fo=\"http://www.w3.org/1999/XSL/Format\" xmlns:argo=\"http://www.navis.com/argo\" version=\"1.1\" >\n" +
            "\t<xsl:template match=\"argo:docDescription\"/>\n" +
            "\t<xsl:template name=\"argo:docBody\"/>\n" +
            "\t<xsl:template match=\"argo:truckVisit\"/>\n" +
            "\t<xsl:template match=\"argo:trkTransaction\">\n" +
            "\t\t<html>\n" +
            "\t\t\t<body>\n" +
            "\t\t\t\t<table cellspacing =\"20\">\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Chassis# / Owner:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranChsNbr\"/>\n" +
            "\t\t\t\t\t\t</td>\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Container# / Owner:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranCtrNbr\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\t\t\t\t\t\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Equipment Type:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranCtrTypeId\"/>\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranGradeId\" />\t\t\t\t\t\t\t\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Yard Row:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranFlexString03\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Trucking Code:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"../argo:truckVisit/tvdtlsTrkCompany\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Trucking Company:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"../argo:truckVisit/tvdtlsTrkCompanyName\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Driver Name:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"../argo:truckVisit/tvdtlsDriverName\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Checker:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranCreator\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Defects:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:for-each select=\"argo:tranCtrDmg\">\t\t\t\n" +
            "\t\t\t\t\t\t\t\t<xsl:value-of select=\"dmgitemType\" />\n" +
            "\t\t\t\t\t\t\t</xsl:for-each>\t\t\t\t\t\t\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Comments:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:for-each select=\"argo:tranCtrDmg\">\t\t\t\n" +
            "\t\t\t\t\t\t\t\t<xsl:value-of select=\"dmgitemDescription\" />\n" +
            "\t\t\t\t\t\t\t</xsl:for-each>\t\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t\t<tr>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">Date:</td>\n" +
            "\t\t\t\t\t\t<td style=\"text-align:left;font-family:Arial;font-size=12pt\">\n" +
            "\t\t\t\t\t\t\t<xsl:value-of select=\"tranStartTime\"/>\n" +
            "\t\t\t\t\t\t</td>\t\t\t\t\t\n" +
            "\t\t\t\t\t</tr>\n" +
            "\t\t\t\t</table>\n" +
            "\t\t\t</body>\n" +
            "\t\t</html>\n" +
            "\t</xsl:template>\n" +
            "</xsl:stylesheet>";
    private Logger LOGGER = Logger.getLogger(MatsonAncPrintDocument.class);
}