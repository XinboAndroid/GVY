import com.navis.inventory.business.imdg.*

 public class GvyHazFlagFix
 {
    public void doit(Object gdsBase)
    {
      //unit.ensureGoods().setFieldValue(com.navis.inventory.InventoryField.GDS_IS_HAZARDOUS, Boolean.FALSE);
      Hazards hazards = gdsBase.getGdsHazards();
        if (hazards == null || hazards.getHzrdItems() == null || hazards.getHzrdItems().isEmpty()) {
           // setGdsIsHazardous(Boolean.FALSE);
           // setGdsImdgTypes(null);
           gdsBase.setFieldValue(com.navis.inventory.InventoryField.GDS_IS_HAZARDOUS, Boolean.FALSE)
           gdsBase.setFieldValue(com.navis.inventory.InventoryField.GDS_IMDG_TYPES, null) 
        } else {
            //setGdsIsHazardous(Boolean.TRUE);
            gdsBase.setFieldValue(com.navis.inventory.InventoryField.GDS_IS_HAZARDOUS, Boolean.TRUE)
            StringBuffer hazCodes = new StringBuffer();
            Iterator it = hazards.getHazardItemsIteratorOrderedBySeverity()
            while (it.hasNext()) {
                HazardItem hazardIt = (HazardItem) it.next();
                ImdgClass code = hazardIt.getHzrdiImdgCode();
                String key = code.getKey();
                String explosiveClass = hazardIt.getHzrdiExplosiveClass();
                if (explosiveClass != null) {
                    key += explosiveClass;
                }

                // 2006-10-18 smahesh v1.2.E ARGO-5246 Added only unique classes to the denormalized list

                // the list wouldn?t be that long.
                if (hazCodes.indexOf(key) == -1) {
                    if (hazCodes.length() > 0) {
                        hazCodes.append(',');
                    }
                    hazCodes.append(key);
                }
            }
            //setGdsImdgTypes(hazCodes.toString());
            gdsBase.setFieldValue(com.navis.inventory.InventoryField.GDS_IMDG_TYPES, hazCodes.toString()) 
        }
     }//Method Ends
   

  }//Class Ends

