// A14   GR   12/13/11  Update HOLD FOR LNK

import com.navis.services.business.event.GroovyEvent
import com.navis.framework.business.Roastery
import com.navis.argo.business.api.ServicesManager
import com.navis.argo.business.api.IFlagType
import com.navis.argo.business.atoms.FlagPurposeEnum
import com.navis.argo.business.reference.*
import com.navis.argo.business.atoms.LogicalEntityEnum;
import com.navis.argo.business.api.LogicalEntity;
import com.navis.argo.business.api.Serviceable;

public class GvyReleaseSnxHolds
{
   def servicesMgr = (ServicesManager)Roastery.getBean("servicesManager"); 
   //Method Get Active Holds for Unit
   public String releaseHoldsPermissions(Object  unit, String notes) 
   {
     if(notes == null){ return }
     com.navis.argo.ContextHelper.setThreadExternalUser("-jms-");
 
     try
    {
      def snxflags = notes.indexOf('(') != -1 && notes.indexOf(')') != -1 ? notes.substring(notes.indexOf('(')+1,notes.indexOf(')')) : ''
      def holdFlags = unit.getFieldValue("unitAppliedHoldOrPermName")
      def flagIds = holdFlags != null ? holdFlags.split(",") : ''
        for(holdId in flagIds)
       {
           def  iFlageType = servicesMgr.getFlagTypeById(holdId)
           def logicalEntity =   iFlageType.getAppliesTo() 
           def flagPurpose =  iFlageType.getPurpose().getKey()
      println("snxflags:"+snxflags+" N4Flags "+flagIds+"  iFlageType::"+iFlageType+"   logicalEntity::"+logicalEntity+"  flagPurpose ::"+flagPurpose)
           if(flagPurpose.equals('HOLD')  && !snxflags.contains(holdId)) 
          {
              println("holdId:"+holdId+" logicalEntity:"+logicalEntity)
              //Releasing Equip Holds
              if(logicalEntity.equals(LogicalEntityEnum.EQ) ||  logicalEntity.equals(LogicalEntityEnum.CTR)){
                    println("Do not Release Equip Holds"+LogicalEntityEnum)
                    //Commented on 05/15/09 as Equi Holds Should be Released 
                   /* def equipmentId = unit.getFieldValue("unitPrimaryUe.ueEquipment.eqIdFull")
                    def equipObj  =  Equipment.loadEquipment(equipmentId); 
                    def operator = com.navis.argo.business.model.Operator.findOperator("MATSON"); 
                    def equipmentState =    com.navis.inventory.business.units.EquipmentState.findEquipmentState(equipObj,operator);
                    releaseHold(equipmentState,holdId) */
              }else if(logicalEntity.equals(LogicalEntityEnum.UNIT) && filterHoldToRel(holdId)){
                    releaseHold(unit,holdId);
              }
          }
       }//for ends
     }catch(Exception e){
         e.printStackTrace()
     }

   }//Method Ends
 
    public String releaseHold(Object unit,String holdId) {
      try
      {
        com.navis.argo.ContextHelper.setThreadExternalUser("-jms-");
        servicesMgr.applyPermission(holdId, unit, null, "Hold Released Through Snx", true) 
      }catch(Exception e){
          e.printStackTrace()
      }
     
    }
  
    public boolean filterHoldToRel(String holdId){
        try{
           String arrHolds = ["TD","TI","TS","ULK","XT","OUTGATE","HOLD FOR LNK","ST","RM","CAR","GX"]
                if(!arrHolds.contains(holdId)){ 
	return true;
               }
           return false
        }catch(Exception e){
           e.printStackTrace()
        }
           
    }

 }