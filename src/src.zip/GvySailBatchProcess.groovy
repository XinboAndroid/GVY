/*
*  A1    Raghu Pattangi      Intial groovy plug-in for sail function (longhaul and barge) reports.
*/
import com.navis.inventory.business.units.UnitFacilityVisit;
import com.navis.argo.business.model.Facility;
import com.navis.apex.business.model.GroovyInjectionBase
import com.navis.services.business.event.Event
import com.navis.argo.business.reference.Equipment
import com.navis.argo.ContextHelper
import com.navis.inventory.business.api.UnitFinder
import com.navis.inventory.business.units.Unit
import com.navis.inventory.business.units.EquipmentState
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import com.navis.argo.business.reports.DigitalAsset;
import java.text.SimpleDateFormat
import java.text.DateFormat
import java.util.HashMap

import com.navis.framework.portal.Ordering;
import com.navis.framework.portal.query.DomainQuery;
import com.navis.framework.portal.QueryUtils;
import com.navis.framework.portal.query.PredicateFactory;
import com.navis.inventory.business.api.UnitField
import com.navis.argo.business.model.CarrierVisit
import com.navis.argo.business.reference.LineOperator;

import com.navis.framework.persistence.HibernateApi;
import com.navis.framework.persistence.Persister;
import  com.navis.framework.business.Roastery
import com.navis.argo.ArgoField;
import com.navis.inventory.business.atoms.UnitVisitStateEnum;
import com.navis.inventory.business.atoms.UfvTransitStateEnum;
import com.navis.argo.business.atoms.UnitCategoryEnum;
import com.navis.argo.business.atoms.FreightKindEnum;
import com.navis.services.business.rules.EventType;
import com.navis.services.business.event.Event;
import com.navis.services.business.api.EventManager
import org.apache.log4j.Logger;

public class GvySailBatchProcess extends GroovyInjectionBase
{
	public static final Logger LOGGER = Logger.getLogger(GvySailBatchProcess.class);
	private String outBoundCarrierId = null
	def inj = null;
	public void init(){
		println("Inside Groovy plug in")
			inj = new GroovyInjectionBase();
	   }

	// This report prints all the rehandled cotainers in the YARD or INBOUND vessel which are not loaded back to the vessel.
	public void  createRehandleContainerRpt(event) {
		LOGGER.info("Begin createRehandleContainerRpt");
		inj = inj==null ? new GroovyInjectionBase(): inj;
		List restowList = new ArrayList(); 
		List rehandleRptList = new ArrayList();
		HashMap map = null;
		def visit = event.getEntity(); 
		def Id = visit.getCvdCv().getCvId()
		def reportDesignName = null; def displayType = null;
		outBoundCarrierId = 		
		visit.vvdVessel.vesId+visit.getFieldValue("vvdObVygNbr")
		
		try
		{
			DomainQuery dq = QueryUtils.createDomainQuery("UnitFacilityVisit")
							.addDqPredicate(PredicateFactory.eq(UnitField.UFV_UNIT_CATEGORY,UnitCategoryEnum.THROUGH))
							.addDqPredicate(PredicateFactory.eq(UnitField.UFV_ACTUAL_OB_ID, Id));

			List unitList = HibernateApi.getInstance().findEntitiesByDomainQuery(dq);
			Iterator iter = unitList.iterator();	
			while(iter.hasNext()) {
				def ufv = iter.next();
				def unit = ufv.ufvUnit;
				def equipType = unit.getFieldValue("unitPrimaryUe.ueEquipment.eqEquipType.eqtypId");
				def restow = unit.getFieldValue("unitActiveUfv.ufvRestowType");
				map = new HashMap();
				restow = restow != null ? restow.getKey(): ''
								def transitState = unit.getFieldValue("unitActiveUfv.ufvTransitState")
				transitState = transitState != null ? transitState.getKey() : ''
				def tState = transitState.split("_")  
				transitState = tState[1]
				LOGGER.info(" Unit number is "+unit.getFieldValue("unitId")+"  restow is "+restow);
				 if ("RESTOW".equals(restow) && "YARD".equals(transitState))
				 {	
					//println(" Unit number is "+unit.getFieldValue("unitId"));                                          
					//println("Remarks are "+unit.getFieldValue("unitRemark"));                                          
					//println(" position slot "+unit.getFieldValue("unitActiveUfv.ufvLastKnownPosition.posSlot")); 
					//println("pos 1: "+ unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot"));               
					//println("pos 2: "+ unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posName"));    
					map.put("UnitNbr",unit.getFieldValue("unitId"));         
					map.put("PositionSlot",unit.getFieldValue("unitActiveUfv.ufvLastKnownPosition.posSlot"));
					map.put("UnitRemark",unit.getFieldValue("unitRemark"));
					map.put("VesselVisitId",Id);
					restowList.add(map);
				 }
			}
			println('restowList ::'+(restowList!= null ? restowList.size() : '0'))
					
			
		    if (restowList != null && restowList.size() > 0 )
			{
				// Create data source with the restowlist to populate on the report.
				JRDataSource ds = new JRMapCollectionDataSource(restowList);
				// get report runner handle
				def reportRunner = inj.getGroovyClassInstance("ReportRunner");

				//Set report parameters
				HashMap parameters = new HashMap();

				// call report design of rehandle containers not loaded back to vessel report.
				reportDesignName = "REHANDLE CONTAINERS NOTLOADED BACK";

				// Emailing report
				 reportRunner.emailReport(ds, parameters,reportDesignName , "rpattangi@matson.com","Rehandle containers not loaded back to "+Id,"");
				 LOGGER.info("End createRehandleContainerRpt");
			}
		}
		catch(Exception ex) {
			LOGGER.info("ERROR createRehandleContainerRpt "+ex.printStackTrace());
		}
	}//method ends


	// This report prints all the empty reefers on the outbound vessel whose destination is "OAK" 
	// and which are flagged as "Clean and Caliberated".
	public void createCleanAndCaliberatedRpt(event) {
		LOGGER.info("Begin createCleanAndCaliberatedRpt");
		inj = inj==null ? new GroovyInjectionBase(): inj;
		def visit = event.getEntity(); 
		def Id = visit.getCvdCv().getCvId()
		HashMap resultMap = null;
		List outputList = new ArrayList();
		def reportDesignName = null;
		try
		{
			DomainQuery dq = QueryUtils.createDomainQuery("UnitFacilityVisit")
							.addDqPredicate(PredicateFactory.eq(UnitField.UFV_ACTUAL_OB_ID,Id))
							.addDqPredicate(PredicateFactory.eq(UnitField.UFV_FREIGHT_KIND, FreightKindEnum.MTY))
							.addDqPredicate(PredicateFactory.eq(UnitField.UFV_DESTIN, "OAK"))
							.addDqOrdering(Ordering.asc(UnitField.UFV_PRIMARY_EQTYPE_ID))
		
			List unitList = HibernateApi.getInstance().findEntitiesByDomainQuery(dq);
			Iterator iter = unitList.iterator();	
			while(iter.hasNext()) {
				def ufv = iter.next();
				def unit = ufv.ufvUnit;
				resultMap = new HashMap();
				def eqType = unit.getFieldValue("unitPrimaryUe.ueEquipment.eqEquipType.eqtypId");
				def transitState = unit.getFieldValue("unitActiveUfv.ufvTransitState")
				def unitNotes = unit.getFieldValue("unitRemark");
				unitNotes = unitNotes != null ? unitNotes : ''
				if (eqType[0] == "R" && unitNotes.contains("CCR") ) {
					println(" Unit number is "+unit.getFieldValue("unitId"));
					println(" Transit state is "+transitState); 
					println(" Equipment type is "+eqType); 
					def cellLocation = unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot");
					if (cellLocation == null)
					{
						cellLocation = ""
					}
					resultMap.put("UnitNbr",unit.getFieldValue("unitId"));         
					resultMap.put("EquipmentType",eqType);                                 
					resultMap.put("ArrivalPositionSlot",cellLocation);
					resultMap.put("Destination",unit.getFieldValue("unitGoods.gdsDestination"));                            
					resultMap.put("VesselVisitId",Id);
					outputList.add(resultMap);
				}
			 }

			 if (outputList != null && outputList.size() !=0)
			 {
				// Create data source with the restowlist to populate on the report.
				JRDataSource ds = new JRMapCollectionDataSource(outputList);
				// get report runner handle
				def reportRunner = inj.getGroovyClassInstance("ReportRunner");

				//Set report parameters
				HashMap parameters = new HashMap();

				// call report design of CLEAN AND CALIBERATE REPORT.
				reportDesignName = "CLEAN AND CALIBERATE REPORT";

				// Emailing report
				 reportRunner.emailReport(ds, parameters,reportDesignName , "rpattangi@matson.com",Id+" MTY RFRS-CLEANED AND CALIBERATED ","");
					 
			 }
	    }
		catch (Exception ex) {
			ex.printStackTrace()
		}

	}//method ends here


	// Creating ZIMX, NORA, FSCO and CCLU owner reports.
	public void createOwnerContainerReport(event) {
		println("createOwnerContainerReport begins");
		def visit = event.getEntity(); 
		def vesselId = visit.getCvdCv().getCvId();
		HashMap ownerMap = null;

		List zimList = new ArrayList();
		List noraList = new ArrayList();
		List ccluList = new ArrayList();
		List fscofhcuList = new ArrayList();
		def owner = null;
		def reportDesignName = null;
		
		try
		{
			DomainQuery dq = QueryUtils.createDomainQuery("UnitFacilityVisit")
								 .addDqPredicate(PredicateFactory.eq(UnitField.UFV_ACTUAL_OB_ID,vesselId))
 								 
				
			List unitOwnerist = HibernateApi.getInstance().findEntitiesByDomainQuery(dq);
			Iterator iterOwner = unitOwnerist.iterator();	
			
			while(iterOwner.hasNext()) {
				def ufv = iterOwner.next();
				def unit = ufv.ufvUnit;
				def unitOwner = unit.getFieldValue("unitPrimaryUe.ueEquipmentState.eqsEqOwner.bzuId");
				
				if (unitOwner.contains("ZIM"))
				{
					ownerMap = new HashMap()
					def cellLocation = unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot");
					if (cellLocation == null)
					{
						cellLocation = ""
					}
					ownerMap.put("UnitNbr",unit.getFieldValue("unitId"));         
					ownerMap.put("FreightKind",unit.getFieldValue("unitCategory").getKey());  // FrieghtKind is initally used just to match the report field. It is actually category.                                  
					ownerMap.put("Destination",unit.getFieldValue("unitGoods.gdsDestination"));                            
					ownerMap.put("POD",unit.getFieldValue("unitRouting.rtgPOD1.pointId"));
					ownerMap.put("ArrivalPositionSlot",cellLocation);
					ownerMap.put("VesselVisitId",vesselId);
					ownerMap.put("EquipmentOwner","ZIM"); 
					zimList.add(ownerMap);
				}
				else if (unitOwner.equals("NORA"))
				{
					ownerMap = new HashMap()
					def cellLocation = unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot");
					if (cellLocation == null)
					{
						cellLocation = ""
					}

					ownerMap.put("UnitNbr",unit.getFieldValue("unitId"));         
					ownerMap.put("FreightKind",unit.getFieldValue("unitCategory").getKey());  // FrieghtKind is initally used just to match the report field. It is actually category.                                  
					ownerMap.put("Destination",unit.getFieldValue("unitGoods.gdsDestination"));                            
					ownerMap.put("POD",unit.getFieldValue("unitRouting.rtgPOD1.pointId"));
					ownerMap.put("ArrivalPositionSlot",cellLocation);
					ownerMap.put("VesselVisitId",vesselId);
					ownerMap.put("EquipmentOwner","NORA"); 
					noraList.add(ownerMap);
				}
				else if (unitOwner.equals("CCLU"))
				{
					ownerMap = new HashMap()
					def cellLocation = unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot");
					if (cellLocation == null)
					{
						cellLocation = ""
					}

					ownerMap.put("UnitNbr",unit.getFieldValue("unitId"));         
					ownerMap.put("FreightKind",unit.getFieldValue("unitCategory").getKey());  // FrieghtKind is initally used just to match the report field. It is actually category.                                  
					ownerMap.put("Destination",unit.getFieldValue("unitGoods.gdsDestination"));                            
					ownerMap.put("POD",unit.getFieldValue("unitRouting.rtgPOD1.pointId"));
					ownerMap.put("ArrivalPositionSlot",cellLocation);
					ownerMap.put("VesselVisitId",vesselId);
					ownerMap.put("EquipmentOwner","CCLU"); 
					ccluList.add(ownerMap);
				}
				else if (unitOwner.equals("FSCO") || unitOwner.equals("FHSU"))
				{
					ownerMap = new HashMap()
					def cellLocation = unit.getFieldValue("unitActiveUfv.ufvArrivePosition.posSlot");
					if (cellLocation == null)
					{
						cellLocation = ""
					}

					ownerMap.put("UnitNbr",unit.getFieldValue("unitId"));         
					ownerMap.put("FreightKind",unit.getFieldValue("unitCategory").getKey());  // FrieghtKind is initally used just to match the report field. It is actually category.                                  
					ownerMap.put("Destination",unit.getFieldValue("unitGoods.gdsDestination"));                            
					ownerMap.put("POD",unit.getFieldValue("unitRouting.rtgPOD1.pointId"));
					ownerMap.put("ArrivalPositionSlot",cellLocation);
					ownerMap.put("VesselVisitId",vesselId);
					ownerMap.put("EquipmentOwner","FHSU"); 
					fscofhcuList.add(ownerMap);
				}
			}

			if (zimList!= null && zimList.size() != 0)
			{
				owner="ZIM"
				createOwnerReport(zimList,vesselId,owner)
			}
			if (noraList!= null && noraList.size() != 0)
			{
				owner="NORA"
				createOwnerReport(noraList,vesselId,owner)
			}
			if (ccluList!= null && ccluList.size() != 0)
			{
				owner="CCLU"
				createOwnerReport(ccluList,vesselId,owner)
			}
			if (fscofhcuList!= null && fscofhcuList.size() != 0)
			{
				owner="FSCO-FHSU"
				createOwnerReport(fscofhcuList,vesselId,owner)
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace()
		}

		println("createOwnerContainerReport ends");
	}

	private createOwnerReport(ownerList,vesselId,owner) {

		def reportDesignName = null
		inj = inj==null ? new GroovyInjectionBase(): inj;
		JRDataSource ds = new JRMapCollectionDataSource(ownerList);
		// get report runner handle
		def reportRunner = inj.getGroovyClassInstance("ReportRunner");

		//Set report parameters
		HashMap parameters = new HashMap();

		// call report design of rehandle containers not loaded back to vessel report.
		reportDesignName = "OWNER CONTAINER REPORT";

		// Emailing report
		 reportRunner.emailReport(ds, parameters,reportDesignName , "rpattangi@matson.com",owner+" containers loaded to "+vesselId,"");		

	} // method ends here

	public void createEBSailingWireRpt(event) {
		println(" Sail function : createEBSailingWireRpt begins")

		def visit = event.getEntity(); 
		def vesselId = visit.getCvdCv().getCvId();
		List outputlist = new ArrayList()
		HashMap outputMap = null
		List intermediateList = new ArrayList();
		inj = inj==null ? new GroovyInjectionBase(): inj;
		def reportDesignName = null;

		try
		{
			DomainQuery dq = QueryUtils.createDomainQuery("UnitFacilityVisit")
								 .addDqPredicate(PredicateFactory.eq(UnitField.UFV_ACTUAL_OB_ID,vesselId))
								 .addDqOrdering(Ordering.asc(UnitField.UFV_DESTIN))
								 .addDqOrdering(Ordering.asc(UnitField.UFV_FREIGHT_KIND))
								 .addDqOrdering(Ordering.asc(UnitField.UFV_PRIMARY_EQTYPE_ID));
			println("Domain query is "+dq);

			List resultList = HibernateApi.getInstance().findEntitiesByDomainQuery(dq);

			println("resultList size is "+resultList.size())

			Iterator itereb = resultList.iterator();

			while (itereb.hasNext())
			{
				outputMap = new HashMap();
				def ufv = itereb.next();
				def unit = ufv.ufvUnit;
				def unitId = unit.getFieldValue("unitId");
				def commodity = unit.getFieldValue("unitGoods.gdsCommodity.cmdyId");
				def dir = unit.getFieldValue("unitFreightKind");
				dir = dir != null ? dir.getKey() : '' 
				if ("FCL".equals(dir) && "AUTO".equals(commodity))
				{
					dir = "AUTO";
				} else if ("FCL".equals(dir) && !"AUTO".equals(commodity))
				{
					dir = "LOAD";
				}
				def destination = unit.getFieldValue("unitGoods.gdsDestination");
				def equipmentType = unit.getFieldValue("unitPrimaryUe.ueEquipment.eqEquipType.eqtypId");
				def loadPort = unit.getFieldValue("unitRouting.rtgPOL.pointId");
				println("Before Map  "+unitId+" "+destination+" "+equipmentType+" "+dir+" "+commodity+" "+loadPort)
				outputMap.put("UnitNbr",unitId);
				outputMap.put("Destination",destination);
				outputMap.put("FreightKind",dir);
				outputMap.put("Commodity",commodity);
				outputMap.put("EquipmentType",equipmentType);
				outputMap.put("POL",loadPort);
				outputMap.put("VesselVisitId",vesselId);
				intermediateList.add(outputMap);
			}

			 if (intermediateList != null && intermediateList.size() !=0)
			 {
				 println("intermediateList size is "+intermediateList.size())
				// Create data source with the restowlist to populate on the report.
				JRDataSource ds = new JRMapCollectionDataSource(intermediateList);
				// get report runner handle
				def reportRunner = inj.getGroovyClassInstance("ReportRunner");

				//Set report parameters
				HashMap parameters = new HashMap();

				// call report design of CLEAN AND CALIBERATE REPORT.
				reportDesignName = "EB SAILING WIRE";

				// Emailing report
				 reportRunner.emailReport(ds, parameters,reportDesignName , "rpattangi@matson.com",vesselId+" ailing wire report ",vesselId+" Sailing wire : Attached are the Total and Detail reports");
					 
			 }

		}
		catch (Exception ex)
		{
			ex.printStackTrace()
		}



	} // method ends here

}//class ends
