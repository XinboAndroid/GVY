public class GvyCmisEventField {

    String fieldName = null;
    String previousValue = null;
    String currentValue = null;

    public void setFieldName(String fieldName)
   {
          this.fieldName = fieldName;
    }
    public String getFieldName()
   {
        return fieldName;
    }

    public void setpreviousValue(String previousValue)
   {
        this.previousValue = previousValue;
    }
    public String getpreviousValue()
   {
        return previousValue;
    }

     public void setCurrentValue(String currentValue)
    {
        this.currentValue = currentValue;
     }
     public String getCurrentValue()
    {
          return currentValue;
     }

}