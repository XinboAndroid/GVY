import com.navis.apex.business.model.GroovyInjectionBase
import com.navis.argo.ContextHelper
import com.navis.argo.business.api.ServicesManager
import com.navis.argo.business.atoms.LocTypeEnum
import com.navis.argo.business.atoms.UnitCategoryEnum
import com.navis.argo.business.model.CarrierVisit
import com.navis.framework.business.Roastery
import com.navis.framework.persistence.HibernateApi
import com.navis.framework.portal.Ordering
import com.navis.framework.portal.QueryUtils
import com.navis.framework.portal.query.DomainQuery
import com.navis.framework.portal.query.PredicateFactory
import com.navis.inventory.InventoryField
import com.navis.inventory.business.api.UnitField
import com.navis.inventory.business.units.UnitFacilityVisit

public class GvyServiceBuisnessRuleForUnit extends GroovyInjectionBase {
    def inj = new GroovyInjectionBase();
    //String vessel = "MHI285";
    //def vesselGkey = "130043692";
    //String vessel = "MHI295";
    //def vesselGkey = "141859481";

    private final String emailTo = "1aktosdevteam@matson.com ";
    private final String emailFrom = '1aktosdevteam@matson.com';
    //public boolean execute(Map params)
    public void execute(Map parameters) {

        println("inside GvyServiceBuisnessRuleForUnit");

        HashMap reportDesignsmap = new HashMap();

        String p2Subject = " ";
        String siSubject = " ";


        ArrayList unitRptList = new ArrayList();
        Long facilityGkey = ContextHelper.getThreadFacility().getFcyGkey();

        println("Started : GvyServiceBuisnessRuleForUnit" + "facilityGkey-->" + facilityGkey + "id" + ContextHelper.getThreadFacility().getFcyId());
        try {
            //List events = getAllDischEvents(vessel);
            ArrayList dischUnits = new ArrayList();
            //Iterator dischItr = events.iterator();
            List acctList = null;
            def type = "DISCHARGE";
            HashMap outputMap = null;
            List resultAcctList = new ArrayList();
            def servicesMgr = (ServicesManager) Roastery.getBean("servicesManager");

            DomainQuery dq = QueryUtils.createDomainQuery("UnitFacilityVisit")
            //.addDqPredicate(PredicateFactory.ne(UnitField.UFV_UNIT_CATEGORY,UnitCategoryEnum.THROUGH))
            //.addDqPredicate(PredicateFactory.like(UnitField.UFV_ARRIVE_POS_LOC_TYPE, "VESSEL"))
            //.addDqPredicate(PredicateFactory.like(UnitField.UFV_ARRIVE_POS_LOC_GKEY, vesselGkey))

            //.addDqPredicate(PredicateFactory.eq(UnitField.UFV_UNIT_ID,"MATU2490330"))
                    .addDqPredicate(PredicateFactory.eq(UnitField.UFV_FACILITY_ID, ContextHelper.getThreadFacility().getFcyId()))
            //.addDqPredicate(PredicateFactory.eq(UnitField.UFV_ACTUAL_OB_CARRIER_MODE, ContextHelper.getThreadFacility().getFcyId()))
            //.addDqPredicate(PredicateFactory.eq(UnitField.UFV_UNIT_VISIT_STATE,UnitVisitStateEnum.ACTIVE))
                    .addDqOrdering(Ordering.desc(InventoryField.UFV_TIME_OF_LAST_MOVE));

            //.addDqOrdering(Ordering.asc(UnitField.UFV_CMDTY));
            acctList = HibernateApi.getInstance().findEntitiesByDomainQuery(dq);
            println("dq====" + dq); //unitCategory UnitCategoryEnum.THROUGH.equals(inUnit.getUnitCategory()
            Iterator unitIter = acctList.iterator();
            while (unitIter.hasNext()) {
                def ufv = unitIter.next()
                def unit = ufv.ufvUnit
                //println("1 unit===="+unit +"unit.getUnitVisitState()-->"+unit.getUnitVisitState() +"unit.getUnitCategory()-->"+unit.getUnitCategory());

                def equiClass = unit.getFieldValue("unitPrimaryUe.ueEquipment.eqEquipType.eqtypClass")
                equiClass = equiClass != null ? equiClass.getKey() : ''

                if (com.navis.inventory.business.atoms.UnitVisitStateEnum.ACTIVE.equals(unit.getFieldValue("unitVisitState")) &&


                        (UnitCategoryEnum.STORAGE.equals(unit.getFieldValue("unitCategory")) ||

                                UnitCategoryEnum.EXPORT.equals(unit.getFieldValue("unitCategory"))) && 'CONTAINER'.equals(equiClass)) {

                    def intdObCarrierId = unit.getFieldValue("unitActiveUfv.ufvActualObCv.cvId");



                    UnitFacilityVisit Unitufv = unit.getUnitActiveUfvNowActive();

                    CarrierVisit actualObCv = Unitufv != null && Unitufv != "" ? Unitufv.getUfvObCv() : null;

                    println("actualObCv: " + actualObCv + " intdObCarrierId -->" + intdObCarrierId);

                    if (actualObCv != null && actualObCv != "") {

                        final LocTypeEnum carrierMode = actualObCv.getCvCarrierMode();

                        println("carrierMode: " + carrierMode);

                        if (carrierMode != null && carrierMode.equals(LocTypeEnum.VESSEL)) {

                            def pod = unit.getFieldValue("unitRouting.rtgPOD1.pointId");

                            if (pod == null || pod == "") {
                                println("Outbound carrier for unitId: " + unit.unitId + " carrierMode " + carrierMode + "pod-->" + pod + " visit state " + unit.getFieldValue("unitVisitState"));
                                resultAcctList.add(unit)
                                println("applying hold");
                                try {
                                    log("unit is "+unit);
                                    servicesMgr.applyHold("PODCHECKFORVESS", unit, null, null, "PODCHECKFORVESS Hold");

                                } catch (Exception e) {
                                    println("Exception in getAllDischEvents " + e);

                                }
                            }

                            //println("Added unit===="+unit +"unitId: "+unitId +" unit.getUnitVisitState()-->"+unit.getUnitVisitState());


                        }

                    }


                }

            }


            println("new resultAcctList.size  " + resultAcctList.size);

        } catch (Exception e) {
            println("Exception in getAllDischEvents " + e);

        }
    }


}

