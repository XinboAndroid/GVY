public class  AcetsConfig1 {
	public String toString() {
		return "TEST";
	}
}